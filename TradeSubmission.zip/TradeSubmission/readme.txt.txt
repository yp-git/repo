API - ASP.NET core service API
DB - SQL server
UI - angular


