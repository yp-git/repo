export class Position
{
    securityCode!: string;
    notional!: number;    
}