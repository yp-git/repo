import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Position } from './position';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public positions : Position[];
  displayedColumns: string[] = ['securitycode', 'notional'];

  constructor(private apiService: ApiService) { 
    this.positions = []    
  }

  ngOnInit(): void {
    this.apiService.get().subscribe((data) => {       
			console.log(data);        
			this.positions = data as Position[];  
		});
  }

}
